package com.example.tic_tac_toe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicTacToeApplicationTests {

	@Test
	void contextLoads() {
	}

}
